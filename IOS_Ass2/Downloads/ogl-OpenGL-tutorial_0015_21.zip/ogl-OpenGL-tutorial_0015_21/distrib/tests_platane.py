from utils import *

	
Clean()

HgUpdate21()
PatchAll()
Build_VC11Express_64()
OptimusForceIntel()
RunAll()
OptimusForceNVIDIA()
RunAll()

Clean()

HgUpdate33()
PatchAll()
Build_VC11Express_64()
OptimusForceNVIDIA()
RunAll()

Clean()
HgUpdate33()
